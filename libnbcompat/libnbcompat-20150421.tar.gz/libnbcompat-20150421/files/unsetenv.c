/*	$NetBSD: unsetenv.c,v 1.1 2004/08/23 03:32:13 jlam Exp $	*/

/*
 * Written by Klaus Klein <kleink@NetBSD.org>, April 1, 2003.
 * Public domain.
 */

#if 0
#define __LIBC12_SOURCE__
#endif

#include "__unsetenv13.c"
