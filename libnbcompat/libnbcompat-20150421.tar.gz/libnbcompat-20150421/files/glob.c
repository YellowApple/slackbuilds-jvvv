/*	$NetBSD: glob.c,v 1.4 2004/08/23 03:32:12 jlam Exp $	*/

/*
 * Written by Jason R. Thorpe <thorpej@NetBSD.org>, October 21, 1997.
 * Public domain.
 */

#if 0
#define __LIBC12_SOURCE__
#endif

#include "__glob13.c"
